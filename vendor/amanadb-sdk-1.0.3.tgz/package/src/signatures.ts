// Signature and encoding helpers shared by the SDK.
//
// Fabric expects DER-encoded ECDSA signatures over SHA-256(message). Two encoding details matter
// and are both handled here so there is a single implementation:
//
//   1. Shape. WebCrypto's ECDSA output is the raw r||s concatenation (IEEE P1363), while Node's
//      crypto.sign('sha256', ...) already produces DER. Fabric verifies DER.
//   2. Canonicity. Fabric's BCCSP *rejects* non-canonical ("high-S") signatures: it requires
//      S <= n/2. A high-S signature makes the peer log
//      "Invalid S. Must be smaller than half the order" and the proposal fails the
//      /Channel/Application/Readers policy with PERMISSION_DENIED. OpenSSL (Node) and WebCrypto
//      both emit high-S roughly half the time, so every signer must normalise to low-S.
//
// The default curve throughout AmanaDB (and Fabric's default) is P-256 (secp256r1/prime256v1),
// so the low-S normalisation below is defined for 32-byte coordinates.

export interface WalletSigner {
    /** Sign the supplied message bytes, returning a DER-encoded, low-S ECDSA signature. */
    sign(message: Uint8Array): Promise<Uint8Array>;
}

export interface Wallet {
    certificatePem: string;
    signer: WalletSigner;
}

// P-256 group order n and n/2, big-endian. Fabric requires S <= n/2.
const P256_ORDER = hexToBytes('ffffffff00000000ffffffffffffffffbce6faada7179e84f3b9cac2fc632551');
const P256_HALF_ORDER = hexToBytes('7fffffff800000007fffffffffffffffde737d56d38bcf4279dce5617e3192a8');
const P256_COORDINATE_BYTES = 32;
const P256_RAW_SIGNATURE_BYTES = P256_COORDINATE_BYTES * 2;

export function bytesToBase64(bytes: Uint8Array): string {
    let binary = '';
    for (const b of bytes) binary += String.fromCharCode(b);
    return btoa(binary);
}

export function base64ToBytes(value: string): Uint8Array {
    const binary = atob(value);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return bytes;
}

function concat(a: Uint8Array, b: Uint8Array): Uint8Array {
    const out = new Uint8Array(a.length + b.length);
    out.set(a, 0);
    out.set(b, a.length);
    return out;
}

function hexToBytes(hex: string): Uint8Array {
    const out = new Uint8Array(hex.length / 2);
    for (let i = 0; i < out.length; i++) out[i] = parseInt(hex.slice(i * 2, i * 2 + 2), 16);
    return out;
}

function leftPad(bytes: Uint8Array, length: number): Uint8Array {
    if (bytes.length >= length) return bytes.slice(bytes.length - length);
    const out = new Uint8Array(length);
    out.set(bytes, length - bytes.length);
    return out;
}

function stripLeadingZeros(value: Uint8Array): Uint8Array {
    let start = 0;
    while (start < value.length - 1 && value[start] === 0) start++;
    return value.slice(start);
}

/** Compare two equal-length big-endian unsigned integers. */
function compareBytes(a: Uint8Array, b: Uint8Array): number {
    if (a.length !== b.length) throw new Error('compareBytes requires equal lengths');
    for (let i = 0; i < a.length; i++) {
        if (a[i] !== b[i]) return a[i]! < b[i]! ? -1 : 1;
    }
    return 0;
}

/** Subtract equal-length big-endian unsigned integers (a - b; requires a >= b). */
function subtractBytes(a: Uint8Array, b: Uint8Array): Uint8Array {
    if (a.length !== b.length) throw new Error('subtractBytes requires equal lengths');
    const out = new Uint8Array(a.length);
    let borrow = 0;
    for (let i = a.length - 1; i >= 0; i--) {
        let diff = a[i]! - b[i]! - borrow;
        if (diff < 0) {
            diff += 256;
            borrow = 1;
        } else {
            borrow = 0;
        }
        out[i] = diff;
    }
    return out;
}

function encodeDerInteger(value: Uint8Array): Uint8Array {
    const stripped = stripLeadingZeros(value);
    const needsPad = stripped.length > 0 && (stripped[0]! & 0x80) !== 0;
    const body = needsPad ? concat(new Uint8Array([0]), stripped) : stripped;
    return concat(new Uint8Array([0x02, body.length]), body);
}

/**
 * Normalise a raw P-256 ECDSA signature (r||s, IEEE P1363) to low-S.
 * Returns the input unchanged when it is already low-S or is not P-256-sized.
 */
export function normalizeRawEcdsaLowS(raw: Uint8Array): Uint8Array {
    if (raw.length !== P256_RAW_SIGNATURE_BYTES) return raw;
    const s = leftPad(stripLeadingZeros(raw.slice(P256_COORDINATE_BYTES)), P256_COORDINATE_BYTES);
    if (compareBytes(s, P256_HALF_ORDER) <= 0) return raw;
    const sLow = subtractBytes(P256_ORDER, s);
    const out = new Uint8Array(P256_RAW_SIGNATURE_BYTES);
    out.set(raw.slice(0, P256_COORDINATE_BYTES), 0);
    out.set(sLow, P256_COORDINATE_BYTES);
    return out;
}

function readDerInteger(der: Uint8Array, offset: number): { value: Uint8Array; next: number } {
    if (der[offset] !== 0x02) throw new Error('Expected a DER INTEGER');
    const length = der[offset + 1]!;
    const start = offset + 2;
    if (length === 0 || start + length > der.length) throw new Error('Invalid DER INTEGER length');
    return { value: der.slice(start, start + length), next: start + length };
}

/** Parse a DER ECDSA signature into raw P-256 r||s (64 bytes). Throws if not a valid signature. */
export function derEcdsaToRaw(der: Uint8Array): Uint8Array {
    if (der.length < 8 || der[0] !== 0x30) throw new Error('Not a DER SEQUENCE');
    let sequenceLength = der[1]!;
    let offset = 2;
    if ((sequenceLength & 0x80) !== 0) {
        const lengthBytes = sequenceLength & 0x7f;
        if (lengthBytes === 0 || lengthBytes > 2 || offset + lengthBytes > der.length) {
            throw new Error('Unsupported DER length encoding');
        }
        sequenceLength = 0;
        for (let i = 0; i < lengthBytes; i++) sequenceLength = (sequenceLength << 8) | der[offset + i]!;
        offset += lengthBytes;
    }
    if (offset + sequenceLength !== der.length) throw new Error('DER length mismatch');

    const r = readDerInteger(der, offset);
    const s = readDerInteger(der, r.next);
    if (s.next !== der.length) throw new Error('Trailing bytes after DER signature');

    // Strip the sign-protecting 0x00 (and any redundant leading zeros) before checking size.
    const rValue = stripLeadingZeros(r.value);
    const sValue = stripLeadingZeros(s.value);
    if (rValue.length > P256_COORDINATE_BYTES || sValue.length > P256_COORDINATE_BYTES) {
        throw new Error('Not a P-256-sized signature');
    }

    const out = new Uint8Array(P256_RAW_SIGNATURE_BYTES);
    out.set(leftPad(rValue, P256_COORDINATE_BYTES), 0);
    out.set(leftPad(sValue, P256_COORDINATE_BYTES), P256_COORDINATE_BYTES);
    return out;
}

/** True when the bytes structurally parse as a DER-encoded ECDSA signature. */
export function isDerEcdsaSignature(bytes: Uint8Array): boolean {
    try {
        derEcdsaToRaw(bytes);
        return true;
    } catch {
        return false;
    }
}

/** Convert a raw IEEE-P1363 ECDSA signature (r||s) into low-S ASN.1 DER. */
export function rawEcdsaToDer(raw: Uint8Array): Uint8Array {
    if (raw.length === 0 || raw.length % 2 !== 0) {
        throw new Error('Expected a raw ECDSA signature with an even byte length');
    }
    const normalized = normalizeRawEcdsaLowS(raw);
    const half = normalized.length / 2;
    const r = encodeDerInteger(normalized.slice(0, half));
    const s = encodeDerInteger(normalized.slice(half));
    const sequence = concat(r, s);
    if (sequence.length > 127) {
        throw new Error('Unsupported DER signature length (expected a P-256-sized signature)');
    }
    return concat(new Uint8Array([0x30, sequence.length]), sequence);
}

/**
 * Accept a signature in either raw r||s or DER form and return canonical, low-S DER.
 * This makes the signer safe against environments whose WebCrypto emits DER already: treating
 * DER as raw would double-encode and produce a signature Fabric cannot verify.
 */
export function toCanonicalDerSignature(signature: Uint8Array): Uint8Array {
    const raw = isDerEcdsaSignature(signature) ? derEcdsaToRaw(signature) : signature;
    return rawEcdsaToDer(raw);
}

// Browser/WebCrypto signer. The private key stays non-extractable: it can sign, but no code
// (including this SDK) can ever read its raw bytes back out.
//
// When the wallet's public key is supplied, each signature is verified against it before being
// returned. That turns a stale/mismatched wallet key (a silent cause of endorsement-policy
// failures) into an immediate, actionable error instead of a PERMISSION_DENIED from the peer.
export function createBrowserSigner(privateKey: CryptoKey, publicKey?: CryptoKey): WalletSigner {
    return {
        async sign(message: Uint8Array): Promise<Uint8Array> {
            // Same secure-context gap as keygen.ts's CSR generation: crypto.subtle is undefined
            // on a plain http://<lan-ip> origin, which would otherwise surface here as an opaque
            // "Cannot read properties of undefined (reading 'sign')" on every wallet login and
            // every signed transaction from such a device, not just enrollment.
            if (typeof window !== 'undefined' && window.isSecureContext === false) {
                throw new Error(
                    'Signing requires a secure context, and this page was loaded over plain HTTP from a ' +
                        'non-localhost address, where browsers disable WebCrypto. Open the dashboard via ' +
                        'http://localhost:5173 (or an SSH tunnel to it) on this device, or serve it over ' +
                        'HTTPS, or use the CLI signer / "Paste signature" fallback for an already-enrolled ' +
                        'identity.',
                );
            }
            if (typeof crypto === 'undefined' || !crypto.subtle) {
                throw new Error('WebCrypto (crypto.subtle) is not available in this browser.');
            }

            const output = new Uint8Array(
                await crypto.subtle.sign({ name: 'ECDSA', hash: 'SHA-256' }, privateKey, message as BufferSource),
            );
            // WebCrypto is specified to return raw r||s; detect and accept DER defensively.
            const raw = normalizeRawEcdsaLowS(
                isDerEcdsaSignature(output) ? derEcdsaToRaw(output) : output,
            );

            if (publicKey) {
                const valid = await crypto.subtle.verify(
                    { name: 'ECDSA', hash: 'SHA-256' },
                    publicKey,
                    raw as BufferSource,
                    message as BufferSource,
                );
                if (!valid) {
                    throw new Error(
                        'Signature self-check failed: the wallet private key does not match the enrolled ' +
                        'certificate public key. Clear this device\'s stored wallet and enroll again.',
                    );
                }
            }

            return rawEcdsaToDer(raw);
        },
    };
}
