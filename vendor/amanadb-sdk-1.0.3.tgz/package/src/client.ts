// AmanaDB TypeScript client.
//
// Zero-trust model: the server never holds a private key, so every chaincode call — even a
// read, because Fabric requires a signed proposal to evaluate — is driven as
// prepare -> sign (in the wallet) -> submit. This client owns that loop; the caller supplies a
// Wallet (certificate + signer) and a project API key.

import { base64ToBytes, bytesToBase64, Wallet } from './signatures';

export type Org = 'org1' | 'org2';
export type AclMode = 'WRITE_ONLY' | 'READ_WRITE';
export type Role = 'admin' | 'client';
export type ProjectRole = 'owner' | 'writer' | 'reader';

// Runtime list (not just the union type above), so the dashboard can render role choices from
// the same source the gateway validates against instead of re-declaring them.
export const PROJECT_ROLES: readonly ProjectRole[] = ['owner', 'writer', 'reader'];

// A project credential (an app's identity) is capped below owner — see docs/Amanadb project
// credentials spec.md D1. Same reasoning as PROJECT_ROLES above: a runtime list, not just a type,
// so UI code renders from the same source the gateway validates against.
export type CredentialRole = 'reader' | 'writer';
export const CREDENTIAL_ROLES: readonly CredentialRole[] = ['reader', 'writer'];
export type CredentialStatus = 'pending' | 'active' | 'revoked';

export interface MeResult {
    name: string;
    role: Role;
    // Always 'developer' today — a project credential can never obtain a session (G1/G2 only
    // ever look up developer registrations), so a 'project'-typed /me response is not currently
    // reachable. Present for forward consistency with other identity-shaped responses.
    type: 'developer' | 'project';
    fabricIdentity: string | null;
    identity: string | null;
    canSign: boolean;
    org: Org | null;
    enrolled: boolean;
}

export interface StorageRecord<T = unknown> {
    projectId: string;
    collection: string;
    key: string;
    ownerId: string;
    acl: string[];
    allowedRoles: string[];
    aclMode: AclMode;
    deleted: boolean;
    data: T;
    version: number;
    createdAt: string;
    updatedAt: string;
}

export interface AuditLogEntry {
    action: string;
    actorId: string;
    // 'developer' | 'project' — see docs/Amanadb project credentials spec.md §1.6. Optional
    // because entries written before this field existed simply don't have it in their stored
    // JSON; treat a missing value as 'developer' (every actor was one, before project
    // credentials existed).
    actorType?: 'developer' | 'project';
    // Set only when actorType is 'project' — which credential made this call.
    credId?: string;
    projectId: string;
    collection: string;
    key: string;
    resultingVersion: number;
    timestamp: string;
    txId: string;
}

export interface Page {
    bookmark: string;
    fetchedRecordsCount: number;
}

export interface RecordsPage<T = unknown> extends Page {
    records: StorageRecord<T>[];
}

export interface AuditLogPage extends Page {
    entries: AuditLogEntry[];
}

export interface CollectionIndexEntry {
    projectId: string;
    collection: string;
    createdAt: string;
}

export interface CollectionsPage extends Page {
    collections: CollectionIndexEntry[];
}

export interface ProjectRecord {
    projectId: string;
    name: string;
    createdBy: string;
    createdAt: string;
    deleted: boolean;
}

export interface ProjectMember {
    username: string;
    role: string;
}

export interface RegistrationResult {
    username: string;
    org: Org;
    status: 'pending';
}

export interface RegistrationRecord {
    username: string;
    org: Org;
    status: 'pending' | 'approved' | 'rejected';
    requestedAt: string;
    reviewedAt?: string;
    reviewedBy?: string;
    rejectionReason?: string;
}

export interface ApprovalResult {
    username: string;
    org: Org;
    mspId: string;
    note: string;
}

export interface LoginResult {
    apiKey: string;
    canSign: boolean;
}

export interface ChallengeResult {
    identityId: string;
    nonce: string;
    expiresAt: string;
}

export interface EnrollmentResult {
    enrollmentId: string;
    org: Org;
    mspId: string;
    certificatePem: string;
    caCertPem: string;
}

export interface CreateProjectResult {
    projectId: string;
    apiKey: string;
}

export interface ProjectCredential {
    credId: string;
    name: string;
    role: CredentialRole;
    status: CredentialStatus;
    createdBy: string;
    createdAt: string;
    // Only present while status is 'pending' — once enrolled or revoked there is no live token.
    tokenExpiresAt?: string;
}

export interface IssueCredentialResult {
    credId: string;
    token: string;
    expiresAt: string;
}

export interface ReissueCredentialTokenResult {
    token: string;
    expiresAt: string;
}

export interface EnrollCredentialResult {
    certificatePem: string;
    caCertPem: string;
    apiKey: string;
    projectId: string;
    credId: string;
    role: CredentialRole;
}

export class AmanaDBError extends Error {
    constructor(message: string, public statusCode: number) {
        super(message);
        this.name = 'AmanaDBError';
    }
}

interface ErrorBody {
    error?: string;
}

interface TxDigest {
    txId: string;
    digest: string;
}

interface FinalTxResult {
    stage: 'committed' | 'evaluated';
    txId: string;
    result: string;
    status?: { successful: boolean; code: number; blockNumber: string; transactionId: string };
    apiKey?: string;
    // Only present for a committed IssueCredential — the raw one-time enrollment token, revealed
    // here for the same reason apiKey is: only after the chain has actually agreed to it.
    token?: string;
}

function stripTrailingSlash(url: string): string {
    return url.replace(/\/$/, '');
}

function parseRecord<T>(raw: StorageRecord<string>): StorageRecord<T> {
    // The chaincode stores opaque payloads as JSON strings, so `data` needs a second parse.
    return { ...raw, data: JSON.parse(raw.data) as T };
}

async function rawRequest<T>(url: string, init: RequestInit): Promise<T> {
    const res = await fetch(url, init);
    if (res.status === 204) return undefined as T;

    const body = (await res.json().catch(() => ({}))) as T & ErrorBody;
    if (!res.ok) {
        throw new AmanaDBError(body.error ?? `Request failed with status ${res.status}`, res.status);
    }
    return body;
}

// Shared transport: holds the base URL, the wallet (certificate + signer), and an optional
// session token for the few project-management routes that use one instead of a signature.
class Transport {
    private readonly baseUrl: string;
    private readonly wallet: Wallet;
    private readonly sessionToken?: string;
    private readonly projectApiKey?: string;

    constructor(baseUrl: string, wallet: Wallet, sessionToken?: string, projectApiKey?: string) {
        this.baseUrl = stripTrailingSlash(baseUrl);
        this.wallet = wallet;
        if (sessionToken !== undefined) this.sessionToken = sessionToken;
        if (projectApiKey !== undefined) this.projectApiKey = projectApiKey;
    }

    private headers(extra?: Record<string, string>): Record<string, string> {
        return {
            ...(this.sessionToken ? { Authorization: `Bearer ${this.sessionToken}` } : {}),
            ...(this.projectApiKey ? { 'X-Project-Key': this.projectApiKey } : {}),
            ...(extra ?? {}),
        };
    }

    async get<T>(path: string): Promise<T> {
        return rawRequest<T>(`${this.baseUrl}${path}`, { headers: this.headers() });
    }

    private async send<T>(method: string, path: string, body?: unknown): Promise<T> {
        return rawRequest<T>(`${this.baseUrl}${path}`, {
            method,
            headers: this.headers({ 'Content-Type': 'application/json' }),
            ...(body !== undefined ? { body: JSON.stringify(body) } : {}),
        });
    }

    /** Public JSON request helper (used for the few session-token routes). */
    sendJson<T>(method: string, path: string, body?: unknown): Promise<T> {
        return this.send<T>(method, path, body);
    }

    // Drives prepare -> sign -> submit until Fabric has all the signatures it needs
    // (proposal signature, then transaction-envelope signature, then commit-status signature).
    private async drive(prepared: TxDigest): Promise<FinalTxResult> {
        let current = prepared;
        // Each chaincode call needs at most three signatures; the loop is bounded defensively.
        for (let i = 0; i < 10; i++) {
            const signature = await this.wallet.signer.sign(base64ToBytes(current.digest));
            const result = await this.send<FinalTxResult | (TxDigest & { stage: string })>('POST', '/tx/submit', {
                txId: current.txId,
                signature: bytesToBase64(signature),
            });
            if (result.stage === 'committed' || result.stage === 'evaluated') {
                return result as FinalTxResult;
            }
            current = { txId: result.txId, digest: (result as TxDigest).digest };
        }
        throw new AmanaDBError('Transaction signing loop did not converge', 500);
    }

    /** Prepare, sign, and evaluate a read. No orderer/commit step. */
    async evaluate<T>(fn: string, args: Array<string | number>): Promise<T> {
        const prepared = await this.send<TxDigest>('POST', '/tx/prepare', {
            function: fn,
            args: args.map(String),
            certificatePem: this.wallet.certificatePem,
            mode: 'evaluate',
        });
        const result = await this.drive(prepared);
        return decodeTransactionResult<T>(result.result);
    }

    /** Prepare a route that itself returns a prepared transaction (projects, records, members). */
    async submitRoute(
        path: string,
        body: Record<string, unknown>,
        onPrepared?: (prepared: TxDigest & Record<string, unknown>) => void,
        method: string = 'POST',
    ): Promise<{ prepared: TxDigest & Record<string, unknown>; result: FinalTxResult }> {
        const prepared = await this.send<TxDigest & Record<string, unknown>>(method, path, {
            ...body,
            certificatePem: this.wallet.certificatePem,
        });
        onPrepared?.(prepared);
        const result = await this.drive(prepared);
        return { prepared, result };
    }
}

function decodeTransactionResult<T>(base64: string): T {
    if (!base64) return undefined as T;
    const text = new TextDecoder().decode(base64ToBytes(base64));
    if (text.length === 0) return undefined as T;
    return JSON.parse(text) as T;
}

export function projectIdFromApiKey(apiKey: string): string {
    const match = /^amdb_pk_([A-Za-z0-9_-]+)_/.exec(apiKey);
    if (!match) throw new Error('Malformed project API key');
    const base64 = match[1]!.replace(/-/g, '+').replace(/_/g, '/');
    const padded = base64 + '='.repeat((4 - (base64.length % 4)) % 4);
    return new TextDecoder().decode(base64ToBytes(padded));
}

// A project credential's token embeds its credId the same way a project API key embeds its
// projectId — not for lookup (the gateway resolves a token by its hash), but so a client can learn
// credId *before* generating its enrollment CSR: Fabric CA requires the CSR's Common Name to
// exactly equal the enrollment ID being registered (cred-<credId>), and credId is otherwise only
// known server-side. Used by `amanadb wallet-init` (found live: enrollment failed with "The CSR
// subject common name must equal the enrollment ID" before this existed).
export function credIdFromToken(token: string): string {
    const match = /^amdb_ct_([A-Za-z0-9_-]+)_/.exec(token);
    if (!match) throw new Error('Malformed credential token');
    const base64 = match[1]!.replace(/-/g, '+').replace(/_/g, '/');
    const padded = base64 + '='.repeat((4 - (base64.length % 4)) % 4);
    return new TextDecoder().decode(base64ToBytes(padded));
}

// --- public (no project key / no session yet) endpoints ---

export async function submitRegistration(
    baseUrl: string, username: string, password: string, org: Org,
): Promise<RegistrationResult> {
    return rawRequest<RegistrationResult>(`${stripTrailingSlash(baseUrl)}/registrations`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password, org }),
    });
}

// Session introspection without a project key or wallet — used right after login to decide
// which shell to route the developer to.
export async function getMe(baseUrl: string, sessionToken: string): Promise<MeResult> {
    return rawRequest<MeResult>(`${stripTrailingSlash(baseUrl)}/me`, {
        headers: { Authorization: `Bearer ${sessionToken}` },
    });
}

// Phase G2: username/password login. The session can browse but cannot sign.
export async function login(baseUrl: string, username: string, password: string): Promise<LoginResult> {
    return rawRequest<LoginResult>(`${stripTrailingSlash(baseUrl)}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
    });
}

// Phase G1: request the nonce to sign.
export async function requestChallenge(baseUrl: string, identityId: string): Promise<ChallengeResult> {
    return rawRequest<ChallengeResult>(`${stripTrailingSlash(baseUrl)}/auth/challenge`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ identityId }),
    });
}

// Phase G1: exchange a wallet signature over the nonce for a signing-capable session.
export async function walletLogin(
    baseUrl: string, identityId: string, nonce: string, signatureBase64: string,
): Promise<LoginResult & { identity?: string }> {
    return rawRequest<LoginResult & { identity?: string }>(`${stripTrailingSlash(baseUrl)}/auth/verify`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ identityId, nonce, signature: signatureBase64 }),
    });
}

// Phase A: submit a browser-generated CSR. The private key is never sent.
export async function enroll(
    baseUrl: string,
    enrollment: { enrollmentId: string; password: string; csrPem: string },
): Promise<EnrollmentResult> {
    return rawRequest<EnrollmentResult>(`${stripTrailingSlash(baseUrl)}/enrollment`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(enrollment),
    });
}

// docs/Amanadb project credentials spec.md §2.3: redeems a one-time token minted by
// issueCredential below. Unauthenticated — the token IS the credential — and no signer needed,
// exactly like enroll() above: the private key is generated by the caller and never sent, only
// the public CSR half is.
export async function enrollCredential(
    baseUrl: string,
    enrollment: { token: string; csrPem: string },
): Promise<EnrollCredentialResult> {
    return rawRequest<EnrollCredentialResult>(`${stripTrailingSlash(baseUrl)}/enrollment/credential`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(enrollment),
    });
}

// --- project management (not tied to a single project key) ---

export interface ProjectManagementOptions {
    baseUrl: string;
    wallet: Wallet;
    sessionToken?: string;
}

function transport(opts: ProjectManagementOptions): Transport {
    return new Transport(opts.baseUrl, opts.wallet, opts.sessionToken);
}

// Phase D: create a project and receive its API key exactly once (after the transaction commits).
export async function createProject(
    opts: ProjectManagementOptions, projectId: string, name: string,
): Promise<CreateProjectResult> {
    const t = transport(opts);
    const { result } = await t.submitRoute('/projects', { projectId, name });
    if (!result.apiKey) {
        throw new AmanaDBError('Project creation committed without returning an API key', 500);
    }
    return { projectId, apiKey: result.apiKey };
}

export async function listProjects(opts: ProjectManagementOptions): Promise<ProjectRecord[]> {
    return transport(opts).get<ProjectRecord[]>('/projects');
}

export async function getProject(opts: ProjectManagementOptions, projectId: string): Promise<ProjectRecord> {
    return transport(opts).get<ProjectRecord>(`/projects/${encodeURIComponent(projectId)}`);
}

export async function listMembers(opts: ProjectManagementOptions, projectId: string): Promise<ProjectMember[]> {
    return transport(opts).get<ProjectMember[]>(`/projects/${encodeURIComponent(projectId)}/members`);
}

export async function addMember(
    opts: ProjectManagementOptions, projectId: string, username: string, role: ProjectRole,
): Promise<void> {
    await transport(opts).submitRoute(`/projects/${encodeURIComponent(projectId)}/members`, { username, role });
}

export async function removeMember(
    opts: ProjectManagementOptions, projectId: string, username: string,
): Promise<void> {
    await transport(opts).submitRoute(
        `/projects/${encodeURIComponent(projectId)}/members/${encodeURIComponent(username)}`,
        {},
        undefined,
        'DELETE',
    );
}

export async function setMemberRole(
    opts: ProjectManagementOptions, projectId: string, username: string, role: ProjectRole,
): Promise<void> {
    await transport(opts).submitRoute(
        `/projects/${encodeURIComponent(projectId)}/members/${encodeURIComponent(username)}`,
        { role },
        undefined,
        'PATCH',
    );
}

export async function rotateProjectKey(
    opts: ProjectManagementOptions, projectId: string,
): Promise<{ projectId: string; apiKey: string }> {
    const t = transport(opts);
    return t.sendJson<{ projectId: string; apiKey: string }>(
        'POST', `/projects/${encodeURIComponent(projectId)}/keys/rotate`,
    );
}

// --- project credentials (apps, capped at reader/writer — see CredentialRole) ---
// docs/Amanadb project credentials spec.md §3. Owner-only on the gateway side; issued/revoked
// through the same prepare -> sign -> submit loop as everything else project-scoped.

export async function issueCredential(
    opts: ProjectManagementOptions, projectId: string, params: { name: string; role: CredentialRole },
): Promise<IssueCredentialResult> {
    const t = transport(opts);
    let credId: string | undefined;
    let expiresAt: string | undefined;
    const { result } = await t.submitRoute(
        `/projects/${encodeURIComponent(projectId)}/credentials`,
        params,
        (prepared) => {
            // Known up front, unlike the token itself — captured from the prepare response so
            // the caller doesn't have to wait for commit just to learn the expiry it already set.
            credId = String(prepared.credId);
            expiresAt = String(prepared.tokenExpiresAt);
        },
    );
    if (!result.token || credId === undefined || expiresAt === undefined) {
        throw new AmanaDBError('Credential issuance committed without returning a token', 500);
    }
    return { credId, token: result.token, expiresAt };
}

export async function listCredentials(opts: ProjectManagementOptions, projectId: string): Promise<ProjectCredential[]> {
    return transport(opts).get<ProjectCredential[]>(`/projects/${encodeURIComponent(projectId)}/credentials`);
}

export async function revokeCredential(
    opts: ProjectManagementOptions, projectId: string, credId: string,
): Promise<void> {
    await transport(opts).submitRoute(
        `/projects/${encodeURIComponent(projectId)}/credentials/${encodeURIComponent(credId)}`,
        {},
        undefined,
        'DELETE',
    );
}

// No chain transaction — same reasoning as rotateProjectKey: a token is a gateway-side enrollment
// secret, not signing authority, so this needs a session but no wallet signature.
export async function reissueCredentialToken(
    opts: ProjectManagementOptions, projectId: string, credId: string,
): Promise<ReissueCredentialTokenResult> {
    const t = transport(opts);
    return t.sendJson<ReissueCredentialTokenResult>(
        'POST', `/projects/${encodeURIComponent(projectId)}/credentials/${encodeURIComponent(credId)}/reissue-token`,
    );
}

// --- admin: registration review (requires an admin session token) ---

export async function listRegistrations(
    baseUrl: string, sessionToken: string, status?: 'pending' | 'approved' | 'rejected',
): Promise<RegistrationRecord[]> {
    const qs = status ? `?status=${status}` : '';
    return rawRequest<RegistrationRecord[]>(`${stripTrailingSlash(baseUrl)}/registrations${qs}`, {
        headers: { Authorization: `Bearer ${sessionToken}` },
    });
}

export async function approveRegistration(
    baseUrl: string, sessionToken: string, username: string,
): Promise<ApprovalResult> {
    return rawRequest<ApprovalResult>(
        `${stripTrailingSlash(baseUrl)}/registrations/${encodeURIComponent(username)}/approve`,
        { method: 'POST', headers: { Authorization: `Bearer ${sessionToken}` } },
    );
}

export async function rejectRegistration(
    baseUrl: string, sessionToken: string, username: string, reason?: string,
): Promise<RegistrationRecord> {
    return rawRequest<RegistrationRecord>(
        `${stripTrailingSlash(baseUrl)}/registrations/${encodeURIComponent(username)}/reject`,
        {
            method: 'POST',
            headers: { Authorization: `Bearer ${sessionToken}`, 'Content-Type': 'application/json' },
            body: JSON.stringify(reason !== undefined ? { reason } : {}),
        },
    );
}

// --- per-project client ---

export interface AmanaDBClientOptions {
    baseUrl: string;
    projectApiKey: string;
    wallet: Wallet;
    // Optional dashboard session token (from password or wallet login) for routes that use it.
    sessionToken?: string;
}

export interface Collection<T = unknown> {
    insert(data: T): Promise<{ id: string; version: number }>;
    update(id: string, data: T, expectedVersion: number): Promise<{ version: number }>;
    upsert(customKey: string, data: T): Promise<{ version: number }>;
    get(id: string): Promise<StorageRecord<T>>;
    list(opts?: { pageSize?: number; bookmark?: string }): Promise<RecordsPage<T>>;
    audit(opts?: { pageSize?: number; bookmark?: string }): Promise<AuditLogPage>;
    delete(id: string, expectedVersion: number): Promise<void>;
}

const MAX_RETRIES = 3;

export class AmanaDBClient {
    private readonly transport: Transport;
    private readonly projectId: string;

    constructor(options: AmanaDBClientOptions) {
        this.transport = new Transport(options.baseUrl, options.wallet, options.sessionToken, options.projectApiKey);
        this.projectId = projectIdFromApiKey(options.projectApiKey);
    }

    me(): Promise<MeResult> {
        return this.transport.get<MeResult>('/me');
    }

    listCollections(opts: { pageSize?: number; bookmark?: string } = {}): Promise<CollectionsPage> {
        return this.transport.evaluate<CollectionsPage>('GetCollections', [
            this.projectId,
            opts.pageSize ?? 20,
            opts.bookmark ?? '',
        ]);
    }

    collection<T = unknown>(name: string): Collection<T> {
        const collectionPath = `/projects/${encodeURIComponent(this.projectId)}/collections/${encodeURIComponent(name)}/records`;
        const t = this.transport;

        const readVersion = async (id: string): Promise<number | null> => {
            try {
                const raw = await t.evaluate<StorageRecord<string>>('GetRecord', [this.projectId, name, id]);
                return raw.version;
            } catch (err) {
                if (err instanceof AmanaDBError && err.statusCode === 404) return null;
                throw err;
            }
        };

        return {
            insert: async (data: T) => {
                // The ULID is generated by the gateway before this call and echoed back, so a
                // retry after a read conflict is repeated with the same id (idempotent).
                let id: string | undefined;
                for (let attempt = 0; attempt < MAX_RETRIES; attempt++) {
                    try {
                        await t.submitRoute(
                            collectionPath,
                            { data, ...(id !== undefined ? { id } : {}) },
                            (prepared) => {
                                id = String(prepared.id);
                            },
                        );
                        return { id: id ?? '', version: 1 };
                    } catch (err) {
                        if (err instanceof AmanaDBError && err.statusCode === 409 && attempt < MAX_RETRIES - 1) {
                            continue;
                        }
                        throw err;
                    }
                }
                throw new AmanaDBError('Insert failed after retries', 409);
            },

            // Optimistic-concurrency conflicts are surfaced to the caller rather than retried:
            // auto-retrying with a re-read version would silently overwrite a concurrent change
            // and discard the caller's expectedVersion precondition.
            update: async (id: string, data: T, expectedVersion: number) => {
                await t.submitRoute(
                    `${collectionPath}/${encodeURIComponent(id)}`,
                    { data, expectedVersion },
                    undefined,
                    'PUT',
                );
                return { version: expectedVersion + 1 };
            },

            upsert: async (customKey: string, data: T) => {
                const known = await readVersion(customKey);
                await t.submitRoute(`${collectionPath}/upsert/${encodeURIComponent(customKey)}`, {
                    data,
                    expectedVersion: known ?? 0,
                });
                // Read back the version the chaincode actually assigned: reviving a soft-deleted
                // key continues from its prior version (existing.version + 1), not 1.
                const persisted = await readVersion(customKey);
                return { version: persisted ?? (known ?? 0) + 1 };
            },

            get: async (id: string) => {
                const raw = await t.evaluate<StorageRecord<string>>('GetRecord', [this.projectId, name, id]);
                return parseRecord<T>(raw);
            },

            list: async (opts = {}) => {
                const raw = await t.evaluate<RecordsPage<string>>('GetRecordsInCollection', [
                    this.projectId,
                    name,
                    opts.pageSize ?? 20,
                    opts.bookmark ?? '',
                ]);
                return { ...raw, records: (raw.records ?? []).map((r) => parseRecord<T>(r)) };
            },

            audit: async (opts = {}) => {
                return t.evaluate<AuditLogPage>('GetCollectionAuditLog', [
                    this.projectId,
                    name,
                    opts.pageSize ?? 20,
                    opts.bookmark ?? '',
                ]);
            },

            delete: async (id: string, expectedVersion: number) => {
                await t.submitRoute(
                    `${collectionPath}/${encodeURIComponent(id)}`,
                    { expectedVersion },
                    undefined,
                    'DELETE',
                );
            },
        };
    }
}
